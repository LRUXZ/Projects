package Breakout;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Ball {
    private Breakout breakout;
    private int x, y;
    private int speedX, speedY, speed;
    private Color color;
    private final int SIZE = 15;

    public Ball(Breakout b, int s) {
        breakout = b;
        x = 225;
        y = 225;
        speed = s;
        speedX = speed;
        speedY = speed;
        color = Color.decode("#123456"); // hex
        // rgb color = new Color(15, 75, 223);
    }

    public void paint(Graphics g) {
        g.setColor(color);
        g.fillOval(x, y, SIZE, SIZE);
    }

    public void move() {
        if (x + speedX < 0) {
            speedX = 2;
        }
        if (x + speedX > breakout.getWidth() - SIZE) {
            speedX = -2;
        }
        x += speedX;
        if (y + speedY < 0) {
            speedY = 2;
        }
        if (y + speedY > breakout.getHeight() - SIZE) {
            speedY = -2;
        }
        y += speedY;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, SIZE, SIZE);
    }

    public boolean collision(int x) {
        return getBounds().intersects(breakout.getBricks().get(x).getBounds());
    }

    public boolean collision2() {
        return getBounds().intersects(breakout.getboundary().getBounds());
    }

    public int setSpeedY(int s) {
        return speedY = s;
    }

    public int setSpeedX(int s) {
        return speedX = s;
    }

    public int getX(int value) {
        return x = value;
    }

    public int getY(int value) {
        return y = value;
    }

}