package Breakout;

public class Game {
    public static void main(String[] args) throws InterruptedException {

        new GameWindow();
    }

}