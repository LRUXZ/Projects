package Breakout;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.util.ArrayList;
import java.util.List;

public class Breakout extends JPanel {
    private Boundary boundary;
    private JLabel winlosslabel;
    private GameWindow game;
    private int speed;
    private int xspeed;
    private int score = 0;
    private Ball ball;
    private Paddle paddle;
    private ArrayList<Color> color;
    private ArrayList<Brick> bricks;
    int offx = 0;
    int offy = 0;
    JButton playAgain = new JButton();

    public Breakout(GameWindow g) {

        game = g;
        playAgain.setBounds(0, 0, 0, 0);
        setBounds(25, 75, 770, 775);
        winlosslabel = new JLabel();
        speed = 2;
        xspeed = 2;
        bricks = new ArrayList<Brick>();
        ball = new Ball(this, speed);
        paddle = new Paddle(this);
        boundary = new Boundary(this);

        playAgain.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                new Game();

            }

        });
        for (int row = 0; row < 15; row++) {
            offx = 0;
            for (int col = 0; col < 14; col++) {
                bricks.add(new Brick(offx, offy, Color.red));
                offx += 50;
            }
            offy += 30;
        }

        addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                paddle.keyPressed(e);

            }

            @Override
            public void keyReleased(KeyEvent e) {
                paddle.keyReleased(e);

            }

        });
        add(playAgain);
        setFocusable(true);
    }

    public void paint(Graphics g) {
        super.paint(g);
        ball.paint(g);
        paddle.paint(g);
        boundary.paint(g);

        winlosslabel.setBounds(200, 300, 100, 100);
        winlosslabel.setBackground(Color.WHITE);
        for (int x = 0; x < bricks.size(); x++) {
            bricks.get(x).paint(g);
            if (ball.collision(x)) {
                ball.setSpeedY(speed);
                bricks.remove(bricks.get(x));
                x--;
                score++;
                game.getlabel().setText("Score: " + score);
                if (score % 10 == 0) {
                    speed++;
                }

            }
            if (score == bricks.size()) {
                game.getlabel2().setText("You Won");
                speed = 0;
                xspeed = 0;
                ball.getX(200);
                ball.getY(300);
                ball.setSpeedY(speed);
                ball.setSpeedX(xspeed);
            }

            if (ball.collision2()) {
                game.getlabel2().setText("You Lost");
                speed = 0;
                xspeed = 0;
                ball.getX(200);
                ball.getY(300);
                ball.setSpeedY(speed);
                ball.setSpeedX(xspeed);

            }
        }

        if (paddle.collision()) {
            ball.setSpeedY(-speed);
            if (score >= 100) {
                speed = 0;
                xspeed = 0;
                ball.setSpeedX(xspeed);
                // System.out.println("yes");
            }
        }
    }

    public void move() {
        ball.move();
        paddle.move();
        paddle.move();
    }

    public Paddle getPaddle() {
        return paddle;
    }

    public Ball getBall() {
        return ball;
    }

    public ArrayList<Brick> getBricks() {
        return bricks;
    }

    public Boundary getboundary() {
        return boundary;
    }

    public int getWidth() {
        return 500;
    } // placeholder

    public int getHeight() {
        return 500;
    } // placeholder

    
}
