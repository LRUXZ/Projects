package Breakout;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;  
    // instance variables
    public class Boundary {
        private Breakout breakout;
        private int x;
        private final int y = 670; 
        private Color color;
        private final int WIDTH =670;
        private final int HEIGHT = 30;
    
        public Boundary(Breakout b) {
            breakout = b; 
            x = 0; 
            color = Color.RED; 
        }

        public void paint(Graphics g) {
            g.setColor(color);
            g.fillRect(x, y, WIDTH, HEIGHT);
        }

		public Rectangle getBounds() {
			return new Rectangle(x, y, WIDTH, HEIGHT);
		}
    }