package Breakout;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

public class GameWindow extends JFrame{
    private JLabel label,label2;
    private int score;
    
    public GameWindow() throws InterruptedException {
        
        setSize(800,800);
        setTitle("Breakout - RAHUL RAMADUGU");
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        score=0;

        label=new JLabel();
        label.setText("Score: " + score);
        label.setBounds(25,10,205,50);
        label.setBackground(Color.WHITE);

        label.setFont(new Font("Ariel", Font.BOLD, 35));

        label2=new JLabel();
        label2.setBounds(300,10,420,50);
        label2.setBackground(Color.WHITE);

        label2.setFont(new Font("Ariel", Font.BOLD, 35));
        add(label);
        add(label2);
        // add Breakout to GameWindow
        Breakout breakout = new Breakout(this);
        add(breakout);


        setVisible(true);
        // game loop
        while(true) {
            breakout.repaint();
            breakout.move();
            Thread.sleep(10);
        }
    
    }
    public int getScore(){
        return score;
    }
    public void setScore(int s){
        score=s;
    }
    public JLabel getlabel(){
        return label;
    }
    public JLabel getlabel2(){
        return label2;
    }
}
        
        

