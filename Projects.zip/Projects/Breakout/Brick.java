package Breakout;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Brick {

    private int x, y;
    private Color color;
    private final int HEIGHT = 43;
    private final int WIDTH = 20;


    public Brick( int xpos, int ypos, Color c) {

        x = xpos;
        y = ypos;

        color = c; // hex
        // rgb color = new Color(15, 75, 223);
    }

    public void paint(Graphics g) {
        g.setColor((Color.BLACK));
        g.drawRect(x,y,HEIGHT,WIDTH);
        
        g.setColor(color);
        g.fillRect(x,y,HEIGHT,WIDTH);

    }

    public Rectangle getBounds() { 
        return new Rectangle(x, y, WIDTH, HEIGHT);
    }
}