package RockPaperScisors;

import java.awt.*;

public class Item {
    private String ID;
    private int speedX, speedY, x, y;

    public Item(String ID, int speedX, int speedY, int x, int y) {
        this.ID = ID;
        this.x = x;
        this.y = y;
        if (speedX == 1)
            this.speedX = speedX * 2;
        else
            this.speedX = -2;
        if (speedY == 1)
            this.speedY = speedY * 2;
        else
            this.speedY = -2;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void move() {
        y += speedY;
        x += speedX;
        if (x + 65 >= 1500)
            speedX = -3;
        if (x <= 50)
            speedX = 3;
        if (y >= 750)
            speedY = -3;
        if (y <= 50)
            speedY = 3;
    }

    public String getID() {
        return ID;
    }

    public int getSpeedX() {
        return speedX;
    }

    public int getSpeedY() {
        return speedY;
    }

    public void setSpeedX(int speedX) {
        this.speedX = speedX;
    }

    public void setSpeedY(int speedY) {
        this.speedY = speedY;
    }

    public void paint(Graphics g) {
        if (ID.equalsIgnoreCase("rock"))
            g.setColor(Color.BLUE);
        else if (ID.equalsIgnoreCase("paper"))
            g.setColor(Color.red);
        else 
            g.setColor(Color.GREEN);
        g.fillRect(x, y, 50, 50);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 49, 49);
    }
}
