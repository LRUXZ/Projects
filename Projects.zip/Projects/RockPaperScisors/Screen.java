package RockPaperScisors;

import java.util.ArrayList;
import java.awt.*;
import javax.swing.*;

public class Screen extends JFrame {
    ArrayList<Item> items;
    private static boolean running = true;

    public Screen() {
        this.setSize(1500, 1000);
        this.getContentPane().setBackground(Color.BLACK);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        items = new ArrayList<>();
        ArrayList<Integer> xpos = new ArrayList<>();
        for (int i = 0; i < 15; i++) {
            int y = (int) (Math.random() * 800);
            int val = y - 75;
            while (xpos.contains(val)) {
                val++;
            }
            y = val;
            String id = "";
            if (i < 5)
                id = "rock";
            else if (i < 10)
                id = "paper";
            else
                id = "scisor";
            int speedX = (int) (Math.random() * -2) + 1;
            int speedY = (int) (Math.random() * -2) + 1;
            items.add(new Item(id, speedX, speedY, i*75, y));
        }
    }

    public void paint(Graphics g) {
        super.paint(g);
        for (int x = 0; x < items.size(); x++) {
            items.get(x).paint(g);
            items.get(x).move();
            for (int y = 0; y < items.size(); y++) {
                if (items.get(x).getBounds().intersects(items.get(y).getBounds())) {
                    if (items.get(x).getID().equalsIgnoreCase("rock")) {
                        if (items.get(y).getID().equals("paper")) {
                            items.get(x).setID("paper");
                        } else if (items.get(y).getID().equalsIgnoreCase("scisor")) {
                            items.get(y).setID("rock");
                        }
                    } else if (items.get(x).getID().equalsIgnoreCase("paper")) {
                        if (items.get(y).getID().equals("scisor")) {
                            items.get(x).setID("scisor");
                        } else if (items.get(y).getID().equalsIgnoreCase("rock")) {
                            items.get(y).setID("paper");
                        }
                    } else if (items.get(x).getID().equalsIgnoreCase("scisor")) {
                        if (items.get(y).getID().equals("rock")) {
                            items.get(x).setID("rock");
                        } else if (items.get(y).getID().equalsIgnoreCase("paper")) {
                            items.get(y).setID("scisor");
                        }
                    }
                    items.get(x).setSpeedY(-items.get(x).getSpeedY());
                    items.get(y).setSpeedY(-items.get(y).getSpeedY());
                    items.get(x).setSpeedX(-items.get(x).getSpeedX());
                    items.get(y).setSpeedX(-items.get(x).getSpeedX());
                }

            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Screen screen = new Screen();
        while (running) {
            Thread.sleep(30);
            screen.repaint();
        }
    }
}
