package Quizlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.*;

public class Quizlet extends JFrame {
    private ArrayList<String> terms, defs;
    public static final int WIDTH = 800, HEIGHT = 625;
    private JButton currentTerm, next, previous;
    private int index;

    public Quizlet() {
        this.setTitle("Quizlet");
        this.setSize(WIDTH, HEIGHT);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setLayout(null);
        this.getContentPane().setBackground(Color.black);

        index = 0;

        defs = new ArrayList<>();
        terms = new ArrayList<>();
        dataSetter();

        currentTerm = new JButton(terms.get(0));
        next = new JButton("NEXT");
        previous = new JButton("PREVIOUS");
        makeElements();

        this.setVisible(true);
    }

    private void dataSetter() {
        ArrayList<String> r = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(new File("Quizlet/Study.txt"));
            while (scanner.hasNextLine()) {
                r.add(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (String item : r) {
            String term, def;
            term = item.substring(0, item.indexOf(":"));
            def = item.substring(item.indexOf(":") + 1);
            terms.add(term);
            defs.add(def);
        }

    }

    private void makeElements() {
        currentTerm.setBackground(Color.WHITE);
        currentTerm.setFocusable(false);
        currentTerm.setFont(new Font("COmic Sans MS", Font.BOLD, 50));
        currentTerm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                if (currentTerm.getText().equals(terms.get(index)))
                    currentTerm.setText(defs.get(index));
                else
                    currentTerm.setText(terms.get(index));
            }
        });
        currentTerm.setBounds(200, 75, 400, 250);
        previous.setBounds(200, 400, 150, 75);
        previous.setEnabled(false);
        previous.setFocusable(false);
        previous.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        previous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                index--;
                if (index < 0) {
                    index++;
                    previous.setEnabled(false);
                    next.setEnabled(true);
                } else {
                    next.setEnabled(true);
                    currentTerm.setText(terms.get(index));
                }
            }
        });
        next.setBounds(450, 400, 150, 75);
        next.setFocusable(false);
        next.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                index++;
                previous.setEnabled(true);
                if (index >= defs.size()) {
                    index--;
                    next.setEnabled(false);
                    previous.setEnabled(true);
                } else {
                    next.setEnabled(true);
                    currentTerm.setText(terms.get(index));
                }
            }
        });

        this.add(previous);
        this.add(next);
        this.add(currentTerm);
    }

    public static void main(String[] args) {
        new Quizlet();
    }
}
