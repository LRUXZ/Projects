package MorseCodeTranslator;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MorseCodeTranslator extends JFrame {
    String translation = " ";
    private JTextField text;
    private JButton translateButton;

    public MorseCodeTranslator() {
        text = new JTextField();
        text.setFont(new Font("Comic Sans Ms", Font.BOLD, 15));
        setSize(800, 625);
        JPanel panel = new JPanel();

        setTitle("Morse Code Translator");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.black);

        JTextArea textArea = new JTextArea();
        JScrollPane pane = new JScrollPane(textArea);
        pane.setBounds(0, 150, 780, 450);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        textArea.setFont(new Font("Comic Sans", Font.BOLD, 30));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setCaretColor(Color.white);

        text.setBounds(0, 0, getWidth(), 50);
        text.setBackground(Color.white);
        text.setOpaque(true);

        translateButton = new JButton("Translate");
        translateButton.setBounds(getWidth() / 2 - 100, 75, 200, 40);
        translateButton.setBackground(Color.white);
        translateButton.setOpaque(true);
        translateButton.setFont(new Font("Comic Sans Ms", Font.BOLD, 20));
        translateButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                translation = translate(text.getText());
                textArea.append(translation + "\n");
                textArea.append("\n");
            }

        });
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(pane);
        add(text);
        add(translateButton);
        add(panel);
        
        setVisible(true);

    }

    public String translate(String s) {
        String t = "";
        for (int x = 0; x < s.length(); x++) {
            t += morseCode(s.substring(x, x + 1)) + " ";
        }
        return t;
    }

    public String morseCode(String i) {
        if (i.equalsIgnoreCase("A")) {
            return ".-";
        } else if (i.equalsIgnoreCase("B")) {
            return "-...";
        } else if (i.equalsIgnoreCase("C")) {
            return ("-.-.");
        } else if (i.equalsIgnoreCase("D")) {
            return ("-..");
        } else if (i.equalsIgnoreCase("E")) {
            return (".");
        } else if (i.equalsIgnoreCase("F")) {
            return ("..-.");
        } else if (i.equalsIgnoreCase("G")) {
            return ("--.");
        } else if (i.equalsIgnoreCase("H")) {
            return ("....");
        } else if (i.equalsIgnoreCase("I")) {
            return ("..");
        } else if (i.equalsIgnoreCase("J")) {
            return (".---");
        } else if (i.equalsIgnoreCase("K")) {
            return ("-.-");
        } else if (i.equalsIgnoreCase("L")) {
            return (".-.. ");
        } else if (i.equalsIgnoreCase("M")) {
            return ("--");
        } else if (i.equalsIgnoreCase("N")) {
            return ("-.");
        } else if (i.equalsIgnoreCase("O")) {
            return ("---");
        } else if (i.equalsIgnoreCase("P")) {
            return (".--.");
        } else if (i.equalsIgnoreCase("Q")) {
            return ("--.-");
        } else if (i.equalsIgnoreCase("R")) {
            return (".-.");
        } else if (i.equalsIgnoreCase("S")) {
            return ("...");
        } else if (i.equalsIgnoreCase("T")) {
            return ("-");
        } else if (i.equalsIgnoreCase("U")) {
            return ("..-");
        } else if (i.equalsIgnoreCase("V")) {
            return ("...-");
        } else if (i.equalsIgnoreCase("W")) {
            return (".--");
        } else if (i.equalsIgnoreCase("X")) {
            return ("-..-");
        } else if (i.equalsIgnoreCase("Y")) {
            return ("-.-- ");
        } else if (i.equalsIgnoreCase("Z")) {
            return ("--..");
        } else if (i.equalsIgnoreCase("0")) {
            return ("-----");
        } else if (i.equalsIgnoreCase("1")) {
            return (".----");
        } else if (i.equalsIgnoreCase("2")) {
            return ("..---");
        } else if (i.equalsIgnoreCase("3")) {
            return ("...--");
        } else if (i.equalsIgnoreCase("4")) {
            return ("....-");
        } else if (i.equalsIgnoreCase("5")) {
            return (".....");
        } else if (i.equalsIgnoreCase("6")) {
            return ("-....");
        } else if (i.equalsIgnoreCase("7")) {
            return ("--...");
        } else if (i.equalsIgnoreCase("8")) {
            return ("---..!");
        } else if (i.equalsIgnoreCase("9")) {
            return ("----.");
        } else if (i.equalsIgnoreCase(" "))
            return "/";
        else if (i.equalsIgnoreCase("."))
            return ".";

        else
            return "";

    }

    public static void main(String[] args) {
        new MorseCodeTranslator();
    }
}