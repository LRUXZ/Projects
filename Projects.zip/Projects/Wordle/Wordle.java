package Wordle;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

public class Wordle extends JFrame {
    private JButton[] buttons;
    private ArrayList<String> guessList;
    private String[] buttonNames = "Q W E R T Y U I O P A S D F G H J K L Z X C V B N M DELETE ENTER CLEAR GIVEUP 1"
            .split(" ");
    private String word;
    private JLabel[][] grid;
    private static int x, y;
    private Wordle current;

    public Wordle() {
        this.setVisible(true);
        this.setTitle("Wordle");
        this.setSize(1000, 1000);
        grid = new JLabel[7][6];
        guessList = readFromFile("C:/VS/EverythingElse/Wordle/Words.txt");
        buttons = new JButton[30];
        word = guessList.get((int) (Math.random() * guessList.size())); // Fixed random index
        word = word.toUpperCase();
        makeElements();
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.black);

        this.addKeyListener(new KeyListener() {

            @Override
            public void keyPressed(KeyEvent e) {
                // NOTHING TO DO HERE
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() >= KeyEvent.VK_A && e.getKeyCode() <= KeyEvent.VK_Z) {
                    new ButtonListener((("" + e.getKeyChar())).toUpperCase());
                } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    new ButtonListener("ENTER");
                } else if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
                    new ButtonListener("DELETE");
                }
            }

            @Override
            public void keyTyped(KeyEvent e) {
                // NOTHING TO DO HERE
            }

        });
        System.out.println("Word to guess: " + word); // Debug
        this.setFocusable(true);
        current = this;
    }

    public void makeElements() {
        int offx = 100, offy = 600, off = 0;
        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new JButton(buttonNames[i]);
            buttons[i].setBounds(offx + off, offy, 75, 75);
            buttons[i].setBackground(Color.white);
            buttons[i].setFocusable(false);
            buttons[i].setFont(new Font("Comic Sans", Font.BOLD, 30));
            offx += 75;
            this.add(buttons[i]);
            buttons[i].addActionListener(new ButtonListener());
            if (i == 9 || i == 18 || i == 25) {
                offx = 150;
                off += 25;
                offy += 75;
            }
        }
        offx = 100;
        for (int i = 0; i < 4; i++) {
            buttons[i + 26].setBounds(offx, offy, 200, 100);
            offx += 200;
        }

        this.remove(buttons[buttons.length - 1]);
        offx = 300;
        offy = 25;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                JLabel label = new JLabel("", SwingConstants.CENTER);
                label.setBounds(offx, offy, 75, 75);
                label.setOpaque(true);
                label.setBackground(Color.white);
                label.setBorder(BorderFactory.createLineBorder(Color.black));
                label.setFont(new Font("Comic Sans", Font.BOLD, 40));
                grid[i][j] = label;
                this.getContentPane().add(grid[i][j]);
                offx += 75;
            }
            offx = 300;
            offy += 75;
        }
        for (int i = 0; i < grid[0].length; i++) {
            this.remove(grid[grid.length - 1][i]);
            this.remove(grid[i][grid[i].length - 1]);
        }
    }

    public static ArrayList<String> readFromFile(String fileName) {
        ArrayList<String> r = new ArrayList<String>();
        try {
            Scanner s = new Scanner(new File(fileName));
            while (s.hasNextLine()) {
                r.add(s.nextLine());
            }
            s.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return r;
    }

    private class ButtonListener implements ActionListener {
        private JButton key;

        ButtonListener() {
        }

        ButtonListener(String e) {
            for (int i = 0; i < buttons.length - 1; i++) {
                if (e.equalsIgnoreCase(buttons[i].getText()))
                    this.key = buttons[i];
            }
            if (key != null)
                eventHappened();
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            key = (JButton) e.getSource();
            eventHappened();
        }

        private void eventHappened() {
            if ((!(key.getText().equals("DELETE") || key.getText().equals("ENTER") || key.getText().equals("CLEAR"))
                    && y < 5)) {
                grid[x][y].setText(key.getText());
                y++;
                current.getContentPane().setBackground(Color.black);
            } else if (key.getText().equalsIgnoreCase("DELETE") && y > 0) {
                grid[x][y - 1].setText("");
                y--;
            } else if (key.getText().equalsIgnoreCase("ENTER") && x < 6) {
                if (y == 5) {

                    y = 0;
                    String guess = "";
                    for (int i = 0; i < 5; i++) {
                        guess += grid[x][i].getText();
                    }

                    char[] guessChars = guess.toCharArray();
                    char[] wordChars = word.toCharArray();
                    Color[] colors = new Color[5];
                    boolean[] used = new boolean[5]; // Tracks letters already matched in word

                    // First pass: green letters
                    for (int i = 0; i < 5; i++) {
                        if (guessChars[i] == wordChars[i]) {
                            colors[i] = Color.GREEN;
                            used[i] = true;
                        }
                    }

                    // Second pass: yellow letters
                    for (int i = 0; i < 5; i++) {
                        if (colors[i] == null) {
                            for (int j = 0; j < 5; j++) {
                                if (!used[j] && guessChars[i] == wordChars[j]) {
                                    colors[i] = Color.YELLOW;
                                    used[j] = true;
                                    break;
                                }
                            }
                            if (colors[i] == null) colors[i] = Color.GRAY;
                        }
                    }

                    // Apply colors to grid and keyboard buttons
                    for (int i = 0; i < 5; i++) {
                        grid[x][i].setBackground(colors[i]);
                        for (JButton b : buttons) {
                            if (b.getText().equalsIgnoreCase("" + guessChars[i])) {
                                Color current = b.getBackground();
                                // Upgrade only: gray < yellow < green
                                if (colors[i] == Color.GREEN || (colors[i] == Color.YELLOW && current != Color.GREEN)) {
                                    b.setBackground(colors[i]);
                                }
                            }
                        }
                    }

                    if (guess.equalsIgnoreCase(word)) {
                        JOptionPane.showMessageDialog(current, "Correct! You win!");
                        System.exit(0);
                    }

                    x++;
                }
            } else
                for (int i = 0; i < 5; i++) {
                    grid[x][i].setText("");
                    y = 0;
                }
        }

        
    }

    public static void main(String[] args) {
        new Wordle();
    }
}
