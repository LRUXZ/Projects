package Space_Invaders;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class Main extends JFrame {
    private ArrayList<Attacker> attackers;

    public Main() {
        super();
        this.setSize(800, 625);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.BLACK);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        makeElements();
        this.addKeyListener(new KeyListener() {

            @Override
            public void keyPressed(KeyEvent event) {

            }

            @Override
            public void keyReleased(KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.VK_UP || KeyEvent.VK_W == event.getKeyCode())
                    System.out.println();
            }

            @Override
            public void keyTyped(KeyEvent event) {

            }

        });
        this.setVisible(true);

    }

    private void makeElements() {

    }

    public static void main(String[] args) {
        new Main();
    }
}
