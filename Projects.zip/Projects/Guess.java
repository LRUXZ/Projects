

// import java.util.Scanner;
// import java.util.ArrayList;

// public class Guess {
//     ArrayList<String> words;
//     String word;
    
//     private void addToList(){
//         words = new ArrayList<>();
//         Scanner scan = new Scanner(File("Python/ords.txt"))
//         while (scan.hasNextLine()){
//             words.add(scan.nextLine());
//         }
//         word = (int)(Math.random()*words.size());
//     }

//     public void playGame(String guess){
//         String output="";
//         for (int x =0; x<word.length();x++){
//             for (int y = 0; y<word.length();y++){
//                 if (x!=y){
//                     if (word.substring(x,x+1).equals(guess.substring(y,y+1))){
//                         output+=word.subString(x,x+1);
//                     }
//                     else if (word.indexOf(guess.subString(y,y+1))){
//                         output+="+"''
//                     }
//                     else
//                         output+="*";
//                 }
//             }
//         }
//     }

//     public static void main(String[] args) {
//         addToList();
//         Scanner scan = new Scanner(System.in);
//         while (scan.hasNextLine()){
//             playGame(scan.nextLine());
//         }
//     }
// }
